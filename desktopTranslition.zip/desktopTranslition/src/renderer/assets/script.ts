const fs = require('fs');
const locales = require('./locales.json');

async function getFlagsAsJson(folderPath) {
  const flags = [];

  try {
    const files = await fs.promises.readdir(folderPath);

    for (const filename of files) {
      if (filename.endsWith('.svg')) {
        const code = filename.slice(0, -4).toUpperCase(); // Remove extension and uppercase code
        const svgData = await fs.promises.readFile(
          folderPath + '/' + filename,
          'utf-8',
        );

        locales.map((locale) => {
          if (code.toUpperCase() === locale.country.code) {
            flags.push({
              locale: locale?.locale,
              language: locale?.language,
              country: locale?.country,
              countryCode: code,
              svgData,
            });
          }
        });
      }
    }
  } catch (error) {
    console.error('Error reading folder:', error);
  }

  return flags;
}

getFlagsAsJson('./svg/').then((flags) => {
  fs.writeFileSync('./flags.json', JSON.stringify(flags));
});
