import React from 'react';

type SVGPreviewProps = {
  svgString: string;
  style?: React.CSSProperties;
};

function SVGPreview({ svgString, style }: SVGPreviewProps): React.ReactElement {
  return (
    <div
      className="svg-preview"
      dangerouslySetInnerHTML={{ __html: svgString }}
      style={
        style || {
          display: 'flex',
        }
      }
    />
  );
}

const MemoizedSVGPreview = React.memo(SVGPreview);

export default MemoizedSVGPreview;
