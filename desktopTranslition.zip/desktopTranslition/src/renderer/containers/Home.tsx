import { useRef, useState } from 'react';
import SearchAppBar from '../components/SearchAppBar';
import { getKeysFromJSONs } from '../utils/getKeysFromJSONs';
import { getLocales } from '../utils/getLocales';
import OrderTable from './OrderTable';
import { writeJSONFile } from '../utils/writeJSONFile';

function Home() {
  const [searchText, setSearchText] = useState([]);
  const [locales, setLocales] = useState([]);
  const [translationkeys, setTranslationkeys] = useState([]);
  const [data, setData] = useState([]);

  const handleFileChange = async (event: {
    target: { files: Iterable<unknown> | ArrayLike<unknown> };
  }) => {
    try {
      let arr = Array.from(event.target.files);
      arr = arr.filter((file) => file.name.endsWith('.json'));
      let { keys, entries } = await getKeysFromJSONs(arr);
      setData(entries);
      setTranslationkeys(Array.from(keys));
      setLocales(Array.from(await getLocales(arr)));
    } catch (error) {
      console.log(error);
    }
  };

  const handleSearch = (event) => {
    setSearchText(event.target.value);
  };

  let temp = useRef({});

  const handleEdit = ({ filename, column, value }) => {
    temp.current[filename][column] = value;
    console.log(temp.current);
    // writeJSONFile('/' + filename, temp.current);
  };

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        height: '100vh',
        width: '100vw',
      }}
    >
      <SearchAppBar onChange={handleSearch} />
      <button
        onClick={() => document.querySelector('input[type="file"]').click()}
      >
        Select i18n folder
      </button>
      <input
        webkitdirectory=""
        type="file"
        onChange={handleFileChange}
        style={{
          display: 'none',
        }}
      />

      {locales.length ? (
        <OrderTable
          keys={translationkeys.filter((key) => key.includes(searchText))}
          headers={locales}
          data={data}
          onEdit={handleEdit}
        />
      ) : null}
    </div>
  );
}

export default Home;
