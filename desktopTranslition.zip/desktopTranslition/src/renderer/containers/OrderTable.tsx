import React, {
  JSXElementConstructor,
  Key,
  ReactElement,
  ReactNode,
  ReactPortal,
  useState,
} from 'react';
import { Link as RouterLink } from 'react-router-dom';

// material-ui
import {
  Link,
  OutlinedInput,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  Typography,
} from '@mui/material';

// third-party
import MemoizedSVGPreview from '../components/SVGPreview';

function descendingComparator(
  a: { [x: string]: number },
  b: { [x: string]: number },
  orderBy: string | number,
) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order: string, orderBy: string) {
  return order === 'desc'
    ? (a: any, b: any) => descendingComparator(a, b, orderBy)
    : (a: any, b: any) => -descendingComparator(a, b, orderBy);
}

function stableSort(
  array: any[],
  comparator: { (a: any, b: any): number; (arg0: any, arg1: any): any },
) {
  const stabilizedThis = array.map((el: any, index: any) => [el, index]);
  stabilizedThis.sort((a: number[], b: number[]) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) {
      return order;
    }
    return a[1] - b[1];
  });
  return stabilizedThis.map((el: any[]) => el[0]);
}

// ==============================|| ORDER TABLE - HEADER ||============================== //

function OrderTableHead({
  headCells = [
    {
      id: 'trackingNo',
      align: 'left',
      disablePadding: false,
      label: 'Tracking No.',
    },
  ],
  order,
  orderBy,
}: {
  order: string;
  orderBy: string;
}) {
  return (
    <TableHead>
      <TableRow>
        {headCells.map(
          (headCell: {
            id: Key | null | undefined;
            align: string | undefined;
            disablePadding: any;
            label:
              | string
              | number
              | boolean
              | ReactElement<any, string | JSXElementConstructor<any>>
              | Iterable<ReactNode>
              | ReactPortal
              | null
              | undefined;
          }) => (
            <TableCell
              key={headCell.id}
              align={headCell.align}
              padding={headCell.disablePadding ? 'none' : 'normal'}
              sortDirection={orderBy === headCell.id ? order : false}
            >
              <MemoizedSVGPreview
                svgString={headCell?.flag}
                style={{
                  width: 50,
                  objectFit: 'fill',
                  boxShadow: '0px 8px 8 0px rgba(24, 39, 75, 0.5)',
                  borderWidth: 2,
                  borderColor: 'black',
                }}
              />
              {headCell.label}-{headCell.id?.slice(0, 2)}
            </TableCell>
          ),
        )}
      </TableRow>
    </TableHead>
  );
}

// ==============================|| ORDER TABLE - STATUS ||============================== //

function OrderStatus({ status }: { status: number }) {
  let color;
  let title;

  switch (status) {
    case 0:
      color = 'warning';
      title = 'Pending';
      break;
    case 1:
      color = 'success';
      title = 'Approved';
      break;
    case 2:
      color = 'error';
      title = 'Rejected';
      break;
    default:
      color = 'primary';
      title = 'None';
  }

  return (
    <Stack direction="row" spacing={1} alignItems="center">
      <Typography>{title}</Typography>
    </Stack>
  );
}

// ==============================|| ORDER TABLE ||============================== //

export default function OrderTable(props: { headers: any[]; keys: any[] }) {
  const [order] = useState('asc');
  const [orderBy] = useState('trackingNo');
  const [selected] = useState([]);

  const isSelected = (trackingNo: any) => selected.indexOf(trackingNo) !== -1;

  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  const headCells = [
    {
      id: '',
      align: 'left',
      disablePadding: false,
      label: 'Translition key',
    },
    ...props?.headers?.map((o: { filename: string; name: string }) => ({
      id: o?.filename,
      align: 'left',
      disablePadding: false,
      label: o?.name,
      flag: o?.flag,
    })),
  ];
  return (
    <Paper>
      <TableContainer
        sx={{
          maxHeight: '80vh',
          width: '100%',
          overflowX: 'auto',
          position: 'relative',
          display: 'block',
          maxWidth: '100%',
          '& td, & th': { whiteSpace: 'nowrap' },
        }}
      >
        <Table
          stickyHeader
          aria-label="sticky table"
          aria-labelledby="tableTitle"
          sx={{
            '& .MuiTableCell-root:first-of-type': {
              pl: 2,
            },
            '& .MuiTableCell-root:last-of-type': {
              pr: 3,
            },
          }}
        >
          <OrderTableHead
            headCells={headCells}
            order={order}
            orderBy={orderBy}
          />
          <TableBody>
            {stableSort(
              props.keys.slice(
                page * rowsPerPage,
                page * rowsPerPage + rowsPerPage,
              ),
              getComparator(order, orderBy),
            ).map((translationkey, index: any) => {
              const isItemSelected = isSelected(translationkey);
              const labelId = `enhanced-table-checkbox-${index}`;

              return (
                <TableRow
                  hover
                  role="checkbox"
                  sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                  aria-checked={isItemSelected}
                  tabIndex={-1}
                  key={translationkey}
                  selected={isItemSelected}
                >
                  <TableCell
                    component="th"
                    id={labelId}
                    scope="row"
                    align="left"
                  >
                    <Link color="secondary" component={RouterLink}>
                      {translationkey}
                    </Link>
                  </TableCell>
                  {props.headers.map((o) => (
                    <TableCell align="left">
                      <OutlinedInput
                        key={o?.filename + '/' + translationkey}
                        id={o?.filename + '/' + translationkey}
                        variant="standard"
                        color="warning"
                        focused
                        defaultValue={
                          props.data?.[o?.filename]?.[translationkey]
                        }
                        onChange={(event) => {
                          props.onEdit({
                            value: event.target.value,
                            filename: o?.filename,
                            column: translationkey,
                          });
                        }}
                      />
                    </TableCell>
                  ))}
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[10, 25, 100]}
        component="div"
        count={props.keys?.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </Paper>
  );
}
