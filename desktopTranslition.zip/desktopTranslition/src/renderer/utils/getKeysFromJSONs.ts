import { readJsonFile } from './readJSON';

/**
 * Retrieves unique keys from multiple JSON files.
 *
 * @param {string[]} files - An array of file paths to JSON files.
 * @return {Set<string>} A set containing unique keys extracted from the JSON files.
 */
export async function getKeysFromJSONs(files: string[]): Promise<any> {
  try {
    const keys = new Set<string>();

    const dataArray = files.map((file) =>
      readJsonFile({ target: { files: [file] } }),
    );

    let entries = {};
    await Promise.all(dataArray).then((data) =>
      data.forEach((json, index) => {
        if (!json) {
          console.log(json);
          return;
        }
        Object.keys(JSON.parse(json).translation).forEach((key) =>
          keys.add(key),
        );
        entries = {
          ...entries,
          [files[index].name]: JSON.parse(json).translation,
        };
      }),
    );

    return { keys, entries };
  } catch (error) {
    console.error(error);
  }
}
