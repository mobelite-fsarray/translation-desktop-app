import flags from '../assets/flags.json';

/**
 * This function maps the array of file objects to an array of objects that
 * contain the file name, flag svgData, and the language name.
 * @param {[]} _files Array of file objects.
 * @returns {Promise<any>} Array of objects containing file name, flag svgData,
 * and language name.
 */
export async function getLocales(_files: []): Promise<any> {
  return _files.map(
    /*
     * @param file File object.
     * @returns Object containing file name, flag svgData, and language name.
     */
    (file: {
      name: string;
    }): {
      filename: string;
      flag: string;
      name: string;
    } => ({
      // filename: file.name?.split('.')[0],
      filename: file.name,
      /*
       * Find the flag with the corresponding country code from the file name
       * in lowercase. If a country code is not found, return undefined.
       */
      flag: flags.find(
        (flag: { country: { code: string } }) =>
          flag.country.code.toLocaleLowerCase() === file.name?.split('.')[0],
      )?.svgData,
      /*
       * Find the flag language name by using the country code from the file
       * name in lowercase. If a country code is not found, return undefined.
       */
      name: flags.find(
        (flag: { country: { code: string } }) =>
          flag.country.code.toLocaleLowerCase() === file.name?.split('.')[0],
      )?.language.name,
    }),
  );
}
