/**
 * Reads a JSON file asynchronously and parses its content.
 *
 * @param {Object} event - An object containing the target file to read
 * @param {Function} cb - A callback function to handle the parsed JSON content
 * @return {void}
 */
export async function readJsonFile(event: {
  target: { files: any };
}): Promise<void> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => resolve(e.target?.result);
    reader.onerror = (e) => reject(e);
    reader.readAsText(event.target.files[0]);
  });
}
