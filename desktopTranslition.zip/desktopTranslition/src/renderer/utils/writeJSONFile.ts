// write in json file
export const writeJSONFile = async (
  filePath: string,
  data: any,
): Promise<void> => {
  return new Promise((resolve, reject) => {
    const fs = require('fs');
    fs.writeFile(filePath, JSON.stringify(data), (err) => {
      if (err) reject(err);
      resolve();
    });
  });
};
